# URL Fish

This extension deletes messages containing phishing links from your server.
